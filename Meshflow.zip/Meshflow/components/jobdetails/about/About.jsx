import React from 'react'
import { View, Text } from 'react-native'

import styles from './about.style'

const About = () => {
  return (
    <View>
      <Text>About</Text>
    </View>
  )
}

export default About