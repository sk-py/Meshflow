import React from 'react'
import { View, Text } from 'react-native'

import styles from './nearbyjobs.style'

const Nearbyjobs = () => {
  return (
    <View>
      <Text>Nearbyjobs</Text>
    </View>
  )
}

export default Nearbyjobs